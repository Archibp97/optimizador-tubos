# Cómo publicar el optimizador en la web — paso a paso

## Lo que vas a tener al final
Una URL propia (ej: `https://tuusuario.github.io/optimizador-tubos`) que podés abrir desde cualquier PC, celular o tablet. El inventario se guarda en la nube y está disponible en todos los dispositivos.

---

## Parte 1 — Base de datos en Supabase (5 minutos)

### 1. Crear cuenta
- Entrá a https://supabase.com y hacé clic en **Start for free**
- Registrate con Google o con email

### 2. Crear proyecto
- Clic en **New project**
- Poné un nombre (ej: `optimizador-tubos`)
- Elegí una contraseña para la base de datos (guardala por las dudas)
- Región: **South America (São Paulo)** — la más cercana
- Clic en **Create new project** (tarda ~2 minutos)

### 3. Crear la tabla
- En el menú izquierdo clic en **SQL Editor**
- Pegá esto y ejecutá con el botón **Run**:

```sql
create table inventario (
  id serial primary key,
  retazos jsonb not null default '[]'::jsonb
);

insert into inventario (retazos) values ('[]'::jsonb);
```

### 4. Copiar las claves
- Ir a **Project Settings** (ícono de engranaje) → **API**
- Copiá:
  - **Project URL** → algo como `https://abcdefgh.supabase.co`
  - **anon public** key → una cadena larga que empieza con `eyJ...`

---

## Parte 2 — Publicar en GitHub Pages (5 minutos)

### 1. Crear cuenta en GitHub
- Entrá a https://github.com y registrate si no tenés cuenta

### 2. Crear repositorio
- Clic en **New repository** (botón verde)
- Nombre: `optimizador-tubos`
- Marcá **Public**
- Marcá **Add a README file**
- Clic en **Create repository**

### 3. Subir el archivo
- En tu repositorio, clic en **Add file → Upload files**
- Arrastrá el archivo `index.html`
- Clic en **Commit changes**

### 4. Activar GitHub Pages
- Ir a **Settings** (dentro del repositorio) → **Pages** (menú izquierdo)
- En **Source** seleccioná **Deploy from a branch**
- Branch: **main** / carpeta: **/ (root)**
- Clic en **Save**
- Esperá 1-2 minutos y tu URL aparece arriba: `https://tuusuario.github.io/optimizador-tubos`

---

## Parte 3 — Primera conexión

- Abrí la URL de GitHub Pages
- Pegá la **Project URL** y la clave **anon public** de Supabase
- Clic en **Conectar**
- ¡Listo! La configuración se guarda en el navegador, no tenés que volver a ingresarla

---

## Notas

- **Gratis:** Supabase free tier permite hasta 500 MB de base de datos y GitHub Pages es gratuito sin límites
- **Seguridad:** La clave `anon` de Supabase es pública por diseño — solo da acceso a la tabla `inventario`
- **Múltiples usuarios:** Si varias personas usan la misma URL comparten el mismo inventario — ideal para un equipo
- **Sin instalación:** Solo necesitás un navegador, funciona en Windows, Mac, Android e iOS
